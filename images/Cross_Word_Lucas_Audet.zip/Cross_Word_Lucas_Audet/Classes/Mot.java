package application;

public class Mot {
    // Variables membres de la classe
    private String indice;
    private String solution;
    private Orientation orientation;
    private Case[] tabCases;
    private int positionX;
    private int positionY;
    private int positionLettre;
    private int score;
    private boolean lettre;

    // Constructeur de la classe
    public Mot(Orientation orientation, String indice, String solution) {
        // Initialisation des variables membres
        this.indice = indice;
        this.solution = solution;
        this.orientation = orientation;
        this.tabCases = new Case[solution.length()];
        this.positionLettre = 0;
        this.score = 0;
        this.lettre = false;
    }

    // Méthodes pour obtenir et définir des informations sur les mots

    public String getIndice() {
        return this.indice;
    }

    public String getSolution() {
        return this.solution;
    }

    public boolean getLettre() {
        return this.lettre;
    }

    public void demandeLettre() {
        this.lettre = true;
    }

    public Orientation getOrientation() {
        return this.orientation;
    }

    public Case[] getTabCases() {
        return this.tabCases;
    }

    public void setTabCases(int position, Case uneCase) {
        this.tabCases[position] = uneCase;
    }

    public int getPositionX() {
        return this.positionX;
    }

    public int getPositionY() {
        return this.positionY;
    }

    public void setPosition(int positionX, int positionY) {
        this.positionX = positionX;
        this.positionY = positionY;
    }

    public int getPositionLettre() {
        return this.positionLettre;
    }

    public void setPositionLettre(int num) {
        this.positionLettre = num;
    }

    public int getScore() {
        return this.score;
    }

    // Cette méthode vérifie si le mot entré par l'utilisateur est correct
    public void verification() {
        // Vérifie si toutes les lettres du mot ont été saisies
        if (positionLettre == solution.length()) {
            // Initialisation du drapeau indiquant si le mot saisi est correct
            boolean motCorrect = true;

            // Création d'un tableau pour stocker le mot saisi par l'utilisateur
            char[] motEcrit = new char[tabCases.length];

            // Remplissage du tableau avec les lettres de la solution
            for (int i = 0; i < tabCases.length; i++) {
                motEcrit[i] = Character.toUpperCase(solution.charAt(i));
            }

            // Vérification caractère par caractère si le mot saisi correspond à la solution
            for (int i = 0; i < tabCases.length && motCorrect; i++) {
                if (Character.toUpperCase(tabCases[i].getContenu()) != motEcrit[i]) {
                    motCorrect = false;  // Une différence a été trouvée, le mot n'est donc pas correct
                }
            }

            // Traitement basé sur la correction du mot
            if (motCorrect) {
                // Le mot est correct
                String couleurReussite = lettre ? "yellow" : "green";  // Couleur basée sur l'utilisation ou non des lettres d'aide
                int scoreCalcul = lettre ? solution.length() : solution.length() * 2;  // Calcul du score

                // Mise à jour des cases avec la couleur de réussite et ajustement du score
                for (int i = 0; i < tabCases.length; i++) {
                    tabCases[i].setCouleur(couleurReussite);
                }

                // Mise à jour de l'indice avec le message de succès
                this.indice = "Bravo!-" + scoreCalcul + "/" + (solution.length() * 2) + "\n" + solution +
                        "\nBonne reponse " + (lettre ? "a l'aide des lettres" : "sans l'aide des lettres") +
                        "\nCliquez sur un numero dans la grille...";

                // Ajustement du score
                this.score = scoreCalcul;
            } else {
                // Le mot est incorrect
                // Mise à jour des cases en rouge et affichage de la solution correcte
                for (int i = 0; i < tabCases.length; i++) {
                    tabCases[i].setCouleur("red");
                    tabCases[i].setContenu(solution.charAt(i));
                }

                // Mise à jour de l'indice avec le message d'échec
                this.indice = "Desole!-0/" + (solution.length() * 2) + "\n" + solution +
                        "\nVous avez ecrit: " + (new String(motEcrit)) +
                        "\nCliquez sur un numero dans la grille...";
            }

            // Verrouillage des cases après la vérification
            for (Case uneCase : tabCases) {
                uneCase.setLock(true);
            }
        }
    }

    // Cette méthode affiche la solution du mot
    public void solution() {
    	for(int i = 0; i<tabCases.length ;i++) {
			tabCases[i].setCouleur("red");
			tabCases[i].setContenu(solution.charAt(i));
			tabCases[i].setLock(true);
			this.indice = "Desole!-"+Integer.toString(solution.length()*2)+"/"+ Integer.toString(solution.length()*2)+"\n"+solution+
					"\nVous avez demande la solution\nCliquez sur un numero dans la grille...";
		}
    }

    // Représentation sous forme de chaîne du mot
    @Override
    public String toString() {
        return "Orientation: " + this.orientation + ", Indice: " + this.indice + ", Solution: " + this.solution;
    }
}
