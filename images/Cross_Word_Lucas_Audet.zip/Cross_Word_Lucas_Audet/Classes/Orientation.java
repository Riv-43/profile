package application;

public enum Orientation {
    HORIZONTALE,
    VERTICALE
}
