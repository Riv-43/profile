package application;

import javafx.geometry.Pos;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

public class Case {

    // Déclaration des propriétés de la classe
    private int positionX;
    private int positionY;
    private char contenu;
    private TextField textField;
    private boolean lock;

    // Constructeur pour initialiser l'objet Case
    public Case(int positionX, int positionY, char contenu) {
        // Initialisation des variables d'instance
        this.positionX = positionX;
        this.positionY = positionY;
        this.contenu = contenu;
        this.lock = false; // Par défaut, la case n'est pas verrouillée

        // Création d'un champ de texte pour afficher le contenu
        this.textField = createTextField(contenu);
    }

    // Méthode pour créer un champ de texte configuré
    private TextField createTextField(char contenu) {
        TextField field = new TextField();

        // Configuration des dimensions du champ de texte
        field.setMinSize(30, 30);
        field.setMaxSize(30, 30);

        // Configuration de la bordure du champ de texte
        BorderStroke borderStroke = new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(2));
        Border border = new Border(borderStroke);
        field.setBorder(border);

        // Configuration de diverses propriétés du champ de texte
        field.setEditable(false); // le champ ne doit pas être éditable
        field.setFocusTraversable(false); // empêche le champ de texte de recevoir le focus
        field.setAlignment(Pos.CENTER); // centre le texte dans le champ

        // Définit le texte du champ avec le contenu actuel, converti en chaîne
        field.setText(Character.toString(contenu));

        return field;
    }

    // Méthode pour récupérer le champ de texte associé à cette case
    public TextField getTextField() {
        return this.textField;
    }

    // Méthode pour récupérer le contenu actuel de la case
    public char getContenu() {
        return this.contenu;
    }

    // Méthode pour définir le contenu de la case, si elle n'est pas verrouillée
    public void setContenu(char contenu) {
        if (!this.lock) { // ne permet de modifier le contenu que si la case n'est pas verrouillée
            this.contenu = Character.toUpperCase(contenu); // stocke le contenu en majuscules
            this.textField.setText(Character.toString(this.contenu)); // met à jour le champ de texte
        }
    }

    // Méthode pour verrouiller ou déverrouiller la case
    public void setLock(boolean lock) {
        this.lock = lock; // verrouille ou déverrouille la case
    }

    // Méthode pour vérifier si la case est verrouillée
    public boolean getLock() {
        return this.lock; // retourne l'état actuel du verrou
    }

    // Méthode pour définir la couleur de fond du champ de texte
    public void setCouleur(String color) {
        // Applique le style CSS au champ de texte pour changer la couleur de fond
        this.textField.setStyle("-fx-background-color: " + color + ";");
    }
}
