package application;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class LectureDonnee {
    
    // Liste pour stocker les objets 'Mot' extraits du fichier
    private ArrayList<Mot> mots;

    // Grille représentant la structure du jeu de mots croisés
    private Case[][] grille;
    
    // Constructeur par défaut
    public LectureDonnee() {
        // Pas de contenu initial nécessaire dans le constructeur
    }
    
    // Méthode pour lire les données des mots depuis un fichier et créer des objets 'Mot'
    public ArrayList<Mot> getListeMots(String chemin) {
        try (BufferedReader br = new BufferedReader(new FileReader(chemin))) {
            mots = new ArrayList<>();  // Initialisation de la liste
            String line;
            while ((line = br.readLine()) != null) {
                // Chaque ligne représente un mot différent
                String[] data = line.split(";");  // Les attributs sont séparés par des points-virgules
                // Détermination de l'orientation du mot
                Orientation orientation = data[0].equals("H") ? Orientation.HORIZONTALE : Orientation.VERTICALE;
                // Nettoyage et extraction de l'indice et de la solution
                String indice = data[1].replaceAll("\"", "").trim();
                String solution = data[2].trim();
                // Création d'un nouvel objet 'Mot' et ajout à la liste
                mots.add(new Mot(orientation, indice, solution));
            }
        } catch (Exception e) {
            // En cas d'erreur, la stack trace sera imprimée
            e.printStackTrace();
        }
        // Renvoie la liste des mots après avoir chargé toutes les données
        return mots;
    }
    
    // Méthode pour construire la grille à partir des données d'un fichier
    public Case[][] getGrille(String chemin) {
        try (BufferedReader br = new BufferedReader(new FileReader(chemin))) {
            // Lecture de la première ligne pour obtenir les dimensions de la grille
            String[] dimensions = br.readLine().split(",");
            int lignes = Integer.parseInt(dimensions[0].trim());
            int colonnes = Integer.parseInt(dimensions[1].trim());
            String[][] fichierGrille = new String[lignes][colonnes];

            // Remplissage de la structure temporaire de la grille
            String ligne;
            int i = 0;
            while ((ligne = br.readLine()) != null) {
                fichierGrille[i] = ligne.split(","); // Les valeurs sont séparées par des virgules
                i++;
            }

            // Initialisation de la grille de jeu
            grille = new Case[lignes][colonnes];

            // Première passe : configuration des cases vides
            for (i = 0; i < fichierGrille.length; i++) {
                for (int j = 0; j < fichierGrille[i].length; j++) {
                    if (Integer.parseInt(fichierGrille[i][j].trim()) == 0) {
                        grille[i][j] = new Case(i, j, ' ');  // Case vide
                    }
                }
            }

            // Deuxième passe : placement des mots dans la grille
            for (i = 0; i < fichierGrille.length; i++) {
                for (int j = 0; j < fichierGrille[i].length; j++) {
                    int valeur = Integer.parseInt(fichierGrille[i][j].trim());
                    if (valeur > 0) {
                        // Configuration des mots dans la grille
                        Mot motActuel = mots.get(valeur - 1);
                        motActuel.setPosition(i, j);
                        for (int n = 0; n < motActuel.getTabCases().length; n++) {
                            if (motActuel.getOrientation() == Orientation.HORIZONTALE) {
                                motActuel.getTabCases()[n] = grille[i][j + n + 1];
                            } else {
                                motActuel.getTabCases()[n] = grille[i + n + 1][j];
                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            // Gestion des exceptions
            e.printStackTrace();
        }
        // Renvoie la grille complète prête à être utilisée dans le jeu
        return grille;
    }
}
