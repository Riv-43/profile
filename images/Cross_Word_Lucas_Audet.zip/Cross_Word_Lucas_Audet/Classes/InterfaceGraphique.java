package application;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;

public class InterfaceGraphique {
	// La liste des mots utilisés dans le jeu, chaque 'Mot' contient des informations comme l'orientation, l'indice, et la solution.
    private ArrayList<Mot> mots;

    // Une grille bidimensionnelle représentant le plateau de jeu, chaque élément est une 'Case' pouvant contenir une lettre.
    private Case[][] grille;

    // Le nom du thème choisi pour le jeu en cours.
    private String nomTheme;

    // L'indice du mot actuellement sélectionné ou en focus dans le jeu.
    private static int currentMot;

    // Le composant racine de l'interface graphique du jeu.
    private BorderPane root;

    // Un composant d'étiquette pour afficher des indices ou des messages à l'utilisateur.
    private Label indice;

    // Un champ de texte pour afficher et gérer le score du joueur.
    private TextField champScore;

    // Un champ de texte pour afficher les lettres mélangées, aidant le joueur à deviner le mot.
    private TextField lettres;
    
    public InterfaceGraphique(String nomTheme, String chemin1, String chemin2) {
    	LectureDonnee lecture = new LectureDonnee();
    	this.nomTheme = nomTheme;
    	mots = lecture.getListeMots(chemin1);
    	grille = lecture.getGrille(chemin2);
    	InterfaceGraphique.currentMot = 0;
    	this.indice = new Label();
    	indice.setWrapText(true);
    	this.champScore = new TextField();
    	this.lettres = new TextField();
    }

    public BorderPane getBorderPane() {
        // Initialisation du BorderPane principal
        root = new BorderPane();

        // Création de la barre de menu
        MenuBar menuBar = new MenuBar();

        // Définir la barre de menu en haut du BorderPane
        root.setTop(menuBar);

        // Création des menus
        Menu themes = new Menu("Thèmes");
        Menu aide = new Menu("Aide");

        // Création des éléments de menu
        MenuItem sport = new MenuItem("Sport");
        MenuItem aPropos = new MenuItem("À propos F1");

        // Ajout d'une action sur 'à propos'
        aPropos.setOnAction(event -> {
            newAlert();
        });

        // Ajout des éléments de menu aux menus
        themes.getItems().add(sport);
        aide.getItems().add(aPropos);

        // Ajout des menus à la barre de menu
        menuBar.getMenus().add(themes);
        menuBar.getMenus().add(aide);

        // Préparation du GridPane
        GridPane grille = new GridPane();
        grille(grille);

        // Demander le focus sur le BorderPane
        root.requestFocus();

        // Configuration du centre du BorderPane
        HBox center = new HBox();
        center.setSpacing(10);
        center.setPadding(new Insets(10));
        root.setCenter(center);

        // Configuration des VBox
        VBox gauche = new VBox();
        gauche.setAlignment(Pos.CENTER);
        VBox droite = new VBox();
        droite.setAlignment(Pos.BOTTOM_LEFT);

        // Ajout des VBox au centre
        center.getChildren().add(gauche);
        center.getChildren().add(droite);

        // Création et configuration du titre
        Label titre = new Label(this.nomTheme);
        titre.setStyle("-fx-font-Weight: Bold; -fx-font-size: 20");

        // Ajout du titre et de la grille à 'left'
        gauche.getChildren().add(titre);
        gauche.getChildren().add(grille);

        // Configuration du message d'accueil
        this.indice.setText("Bienvenue! Pour jouer, cliquez sur un" + "\n" + 
                    "numéro dans la grille, écrivez le mot et" + "\n" + 
                    "cliquez sur OK ou appuyez sur la" + "\n" + 
                    "touche Entrée (Enter) pour continuer");
        indice.setStyle("-fx-font-Weight: Bold; -fx-font-size: 15");

        // Ajout du menu
        GridPane menu = createMenu();
        droite.getChildren().add(indice);
        droite.getChildren().add(menu);

        // Gestionnaire d'événements pour les touches pressées
        root.setOnKeyPressed(event -> {
            String lettreTapee = event.getText();
            try {
                Mot mot = mots.get(currentMot);
                int positionLettre = mot.getPositionLettre();
                if (event.getCode() == KeyCode.BACK_SPACE && mot.getPositionLettre() > 0) {
                    try {
                        if(mot.getTabCases()[positionLettre - 1].getLock()){
                            positionLettre--;
                        }
                    } catch (Exception e) {
                        // Exception ignorée
                    }

                    mot.getTabCases()[positionLettre - 1].setContenu(' ');
                    mot.setPositionLettre(positionLettre - 1);
                } else if(positionLettre < mot.getSolution().length()) {
                    try {
                        if(mot.getTabCases()[positionLettre].getLock()){
                            positionLettre++;
                        }
                    } catch (Exception e) {
                        // Exception ignorée
                    }

                    mot.getTabCases()[positionLettre].setContenu(lettreTapee.charAt(0));
                    mot.setPositionLettre(positionLettre + 1);
                }

                BorderPane.clearConstraints(grille);
                grille(grille);

            } catch(Exception e) {
                // Exception ignorée
            }
        });

        // Retour du BorderPane configuré
        return root;
    }

        
    public GridPane createMenu() {
	    // Création d'un nouveau GridPane qui servira de layout principal pour le menu
	    GridPane base = new GridPane();
	    base.setAlignment(Pos.CENTER);
	    base.setVgap(10);
	    
	
	    // Configuration de la bordure du layout
	    BorderStroke contourtMenu = new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, new CornerRadii(0), new BorderWidths(4));
	    Border bordureMenu = new Border(contourtMenu);
	    base.setBorder(bordureMenu);
	    
	    // Configuration d'une bordure commune pour plusieurs éléments
	    BorderStroke traitBord = new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(2));
	    Border bordure = new Border(traitBord);
	    
	    // Configuration de la police commune pour plusieurs éléments
	    Font font = Font.font("Arial", FontWeight.BOLD, 18);
	    
	    
	    lettres.setEditable(false);
	    lettres.setAlignment(Pos.CENTER);
	    lettres.setBorder(bordure);
	    
	    base.add(lettres, 0, 0);

	    
	    // Création d'un HBox pour les boutons "LETTRES" et "SOLUTION"
	    HBox hbox = new HBox(10);
	    BackgroundFill remplissageBeige = new BackgroundFill(Color.BEIGE, new CornerRadii(5), new Insets(0));
	    Background fondBeige = new Background(remplissageBeige);
	    
	    Button btnLettres = new Button("LETTRES");
	    btnLettres.setPrefWidth(140);
	    btnLettres.setFont(font);
	    btnLettres.setBackground(fondBeige);
	    btnLettres.setBorder(bordure);
	    btnLettres.setOnAction(event -> {
	    	mots.get(InterfaceGraphique.currentMot).demandeLettre();
	    	lettres.setText(randomLetters(mots.get(InterfaceGraphique.currentMot).getSolution()));
	    });
	    
	    Button solutionButton = new Button("SOLUTION");
	    solutionButton.setPrefWidth(140);
	    solutionButton.setFont(font);
	    solutionButton.setBackground(fondBeige);
	    solutionButton.setBorder(bordure);	    
	    hbox.setAlignment(Pos.CENTER);
	    hbox.getChildren().addAll(btnLettres, solutionButton);
	    solutionButton.setOnAction(event -> {
	    	mots.get(InterfaceGraphique.currentMot).solution();
	    	this.indice.setText(mots.get(InterfaceGraphique.currentMot).getIndice());
	    });
	    
	    // Création d'un HBox pour le bouton "OK"
	    HBox ok = new HBox();
	    Button okButton = new Button("OK");
	    okButton.setBackground(fondBeige);
	    okButton.setFont(font);
	    okButton.setBorder(bordure);
	    ok.getChildren().add(okButton);
	    ok.setAlignment(Pos.CENTER);
	    okButton.setOnAction(event -> {
	    	mots.get(InterfaceGraphique.currentMot).verification();
	    	int currentScore = 0;
		    for(int i = 0; i<mots.size();i++) {
		    	currentScore = currentScore + mots.get(i).getScore();
		    }
		    champScore.setText(Integer.toString(currentScore));
		    this.indice.setText(mots.get(InterfaceGraphique.currentMot).getIndice());
	    });
	    
	    // Création d'un HBox pour les scores
	    HBox hbox2 = new HBox(10);
	    BackgroundFill backGroundJaune = new BackgroundFill(Color.GOLD, new CornerRadii(10), new Insets(-5));
	    Background fondJaune = new Background(backGroundJaune);
	    
	    // Configuration du premier VBox (pour le score actuel)
	    VBox vbox = new VBox(3);
	    Label labelScore = new Label("VOTRE SCORE");
	    labelScore.setFont(font);
	    champScore.setText("0");
	    
	    champScore.setEditable(false);
	    champScore.setAlignment(Pos.CENTER);
	    champScore.setFont(font);
	    champScore.setMaxWidth(140);
	    champScore.setPrefHeight(35);
	    vbox.getChildren().addAll(labelScore,champScore);
	    vbox.setBackground(fondJaune);
	    vbox.setAlignment(Pos.CENTER);
	    
	    // Configuration du deuxième VBox (pour le score maximum)
	    VBox vbox2 = new VBox(3);
	    Label labelMax = new Label("MAXIMUM");
	    labelMax.setFont(font);
	    //calculMaxScore();  // Apparemment une méthode pour calculer le score max, mais elle n'est pas appelée ici
	    TextField textMaxScore = new TextField();
	    int scoremax = 0;
	    for(int i = 0; i<mots.size();i++) {
	    	scoremax = scoremax + (mots.get(i).getSolution().length())*2;
	    }
	    textMaxScore.setText(Integer.toString(scoremax));
	    textMaxScore.setEditable(false);
	    textMaxScore.setAlignment(Pos.CENTER);
	    textMaxScore.setFont(font);
	    textMaxScore.setMaxWidth(140);
	    textMaxScore.setPrefHeight(35);
	    vbox2.getChildren().addAll(labelMax, textMaxScore);
	    vbox2.setBackground(fondJaune);
	    vbox2.setAlignment(Pos.CENTER);
	    hbox2.getChildren().addAll(vbox, vbox2);
	    
	    // Création d'un HBox pour le bouton "AIDE"
	    HBox aide = new HBox();
	    Button aideButton = new Button("AIDE");
	    aideButton.setBackground(fondBeige);
	    aideButton.setBorder(bordure);
	    aideButton.setFont(font);
	    aide.getChildren().add(aideButton);
	    aide.setAlignment(Pos.CENTER);
	    // Ajout d'un gestionnaire d'événements pour le bouton "AIDE"
	    GestionnaireClicAide gestionAideClick = new GestionnaireClicAide();
	    aideButton.setOnMouseClicked(gestionAideClick);	    
	    // Ajout de tous les éléments au layout principal
	    //racine.add(champLettresAleatoires, 0, 0);
	    base.add(hbox, 0, 1);
	    base.add(ok, 0, 2);
	    base.add(hbox2, 0, 3);
	    base.add(aide, 0, 4);	    
	    // Configuration des marges pour chacun des éléments du layout principal
	    Insets enteteEnHaut = new Insets(10, 10, 0 ,10);
	    Insets enteteAuCentre = new Insets(0, 10, 0 ,10);
	    Insets enteteEnBas = new Insets(0, 10, 10 ,10);
	    //GridPane.setMargin(champLettresAleatoires, margesHaut);
	    GridPane.setMargin(lettres, enteteEnHaut);

	    GridPane.setMargin(hbox, enteteAuCentre);
	    GridPane.setMargin(ok, enteteAuCentre);
	    GridPane.setMargin(hbox2, enteteAuCentre);
	    GridPane.setMargin(aide, enteteEnBas);	    
	    // Retourne le layout principal
	    return base;
	}
    
    private void grille(GridPane gridPane) {
        gridPane.setHgap(7);
        gridPane.setVgap(7);
        gridPane.setAlignment(Pos.CENTER);
        for(int i =0; i<grille.length;i++) {
        	for(int j=0;j<grille[i].length;j++) {
        		if(grille[i][j] != null) {
        			gridPane.add(grille[i][j].getTextField(), j, i);
        		}
        	}
        }
        for(int i=0;i<mots.size();i++) {
        	StackPane panneau = new StackPane();
            Circle cercle = new Circle(15, Color.BLACK);
            GridPane.setHalignment(cercle, javafx.geometry.HPos.CENTER);
            GridPane.setValignment(cercle, javafx.geometry.VPos.CENTER);
            Text text = new Text(String.valueOf(i+1));
            text.setFill(Color.WHITE);
            text.setStyle("-fx-font-size: 16; -fx-font-weight: bold;");
            panneau.getChildren().addAll(cercle, text);
            panneau.setAlignment(Pos.CENTER);
            GestionnaireClicCercle gestionClickCercle = new GestionnaireClicCercle(currentMot, i, this.indice, this.mots);
            panneau.setOnMouseClicked(gestionClickCercle);
            gridPane.add(panneau, mots.get(i).getPositionY(), mots.get(i).getPositionX());
        }
    }
    
    
    private class GestionnaireClicCercle implements EventHandler<MouseEvent> {
        // La valeur du cercle cliqué.
        private static int focusedMot;
        private Label indice;
        private ArrayList<Mot> listMots;
        private int newMot;

        // Constructeur avec une valeur spécifique du cercle.
        public GestionnaireClicCercle(int motEnFocus, int nouveauMot, Label indice, ArrayList<Mot> listMots) {
            this.newMot = nouveauMot;
            this.indice = indice;
            this.listMots = listMots;
            InterfaceGraphique.currentMot = motEnFocus;
        }

        // Lorsqu'un cercle est cliqué, cette méthode est appelée.
        @Override
        public void handle(MouseEvent event) {
            // Affichage des valeurs pour le débogage
            showOldWordAndNewword();

            // Réinitialiser le contenu du mot précédemment sélectionné
            changerLeMotDAvant();

            // Mise à jour de motEnFocus
            InterfaceGraphique.currentMot = newMot;

            // Mise à jour de l'indice affiché
            indice.setText(listMots.get(InterfaceGraphique.currentMot).getIndice());

            // Nouvelle affichage des valeurs pour le débogage
            showOldWordAndNewword();

            // Faire en sorte que le focus principal soit sur la racine
            root.requestFocus();

            // Mise à jour du texte des lettres
            miseAJourLabel();
        }

        // Affichage des valeurs pour le débogage
        private void showOldWordAndNewword() {
            System.out.println(focusedMot + "-" + newMot);
        }

        // Réinitialiser le contenu du mot précédemment sélectionné
        private void changerLeMotDAvant() {
            int motAvant = InterfaceGraphique.currentMot;
            for (int i = 0; i < listMots.get(motAvant).getTabCases().length; i++) {
                listMots.get(motAvant).getTabCases()[i].setContenu(' ');
            }
            listMots.get(motAvant).setPositionLettre(0);
        }

        // Mise à jour du texte des lettres
        private void miseAJourLabel() {
            if (listMots.get(InterfaceGraphique.currentMot).getLettre()) {
                lettres.setText(randomLetters(listMots.get(InterfaceGraphique.currentMot).getSolution()));
            } else {
                lettres.setText("");
            }
        }
    }

    
    
    private Alert newAlert() {
        // Création de l'objet Alert sans type spécifique
        Alert alerte = new Alert(AlertType.NONE);

        // Personnalisation du titre de la fenêtre d'alerte
        final String titreAlerte = "À propos";
        alerte.setTitle(titreAlerte);

        // Suppression de l'en-tête par défaut
        alerte.setHeaderText(null);

        // Création d'un nouveau panneau de dialogue
        DialogPane panneauDialogue = new DialogPane();

        // Création d'une boîte verticale pour disposer les éléments
        VBox vbox = new VBox();
        final double espacementVertical = 5.0;
        vbox.setSpacing(espacementVertical);

        // Définition des polices de caractères pour différents éléments de texte
        final String nomPolice = "Arial";
        final double taillePoliceTitre = 20.0;
        Font policeTitre = Font.font(nomPolice, FontWeight.BOLD, taillePoliceTitre);
        final double taillePoliceTexte = 14.0;
        Font policeTexte = Font.font(nomPolice, taillePoliceTexte);

        // Création des éléments de texte avec les règles du jeu
        Text titreDesRegles = new Text("Règles du jeu");
        titreDesRegles.setFont(policeTitre);

        // Appel à une méthode pour obtenir le texte des règles
        String texteDesRegles = getStringDesRegles();
        Text reglesTexte = new Text(texteDesRegles);
        reglesTexte.setFont(policeTexte);

        // Création des éléments de texte pour le calcul du score
        Text titreDuScore = new Text("Calcul du Score");
        titreDuScore.setFont(policeTitre);

        // Appel à une méthode pour obtenir le texte du calcul du score
        String texteDuScore = getStringDuScore();
        Text scoreTexte = new Text(texteDuScore);
        scoreTexte.setFont(policeTexte);

        // Création des éléments de texte pour les informations sur l'auteur
        Text titreDeLAuteur = new Text("Auteur");
        titreDeLAuteur.setFont(policeTitre);

        Text auteurTexte = new Text("Lucas Audet");
        auteurTexte.setFont(policeTexte);

        // Ajout de tous les éléments au VBox
        vbox.getChildren().addAll(titreDesRegles, reglesTexte, titreDuScore, scoreTexte, titreDeLAuteur, auteurTexte);

        // Définition du contenu du panneau de dialogue
        panneauDialogue.setContent(vbox);

        // Ajustement des dimensions minimales
        panneauDialogue.setMinHeight(Region.USE_PREF_SIZE);
        panneauDialogue.setMinWidth(Region.USE_PREF_SIZE);

        // Définition du panneau de dialogue pour l'alerte
        alerte.setDialogPane(panneauDialogue);

        // Ajout d'espacement autour du VBox
        Insets margeVBox = new Insets(10, 10, 10, 10);
        vbox.setPadding(margeVBox);

        // Création d'un bouton de type pour fermer la fenêtre d'alerte
        ButtonType boutonFermer = new ButtonType("OK", ButtonBar.ButtonData.CANCEL_CLOSE);
        panneauDialogue.getButtonTypes().add(boutonFermer);

        // Affichage de l'alerte et attente d'une action de l'utilisateur
        alerte.showAndWait();

        // Retour de l'objet alerte
        return alerte;
    }

	// Méthode pour obtenir la chaîne de caractères des règles du jeu
	private String getStringDesRegles() {
	    return "Cliquez sur un numéro pour sélectionner le mot" + "\n" +
	            "correspondant et obtenir l'indice du mot recherché. Vous" + "\n";
	}

	// Méthode pour obtenir la chaîne de caractères de l'explication du score
	private String getStringDuScore() {
	    return "Un mot exact obtenu seulement à l'aide de l'indice vous" + "\n" +
	            "donne un nombre de points égal à deux fois le nombre de" + "\n";
	}


	public String randomLetters(String mot) {
	    // Vérification si le mot n'est pas null ou vide
	    if (mot == null || mot.isEmpty()) {
	        throw new IllegalArgumentException("Le mot ne peut pas être null ou vide");
	    }

	    // Conversion de la chaîne en tableau de caractères pour le traitement
	    char[] lettres = mot.toCharArray();

	    // Création d'un objet Random pour le mélange
	    Random random = new Random();

	    // Obtenir la longueur du mot pour éviter de multiples appels de méthode
	    int longueurDuMot = lettres.length;

	    // Si le mot n'est composé que d'un seul caractère, le retourner tel quel
	    if (longueurDuMot == 1) {
	        return mot;
	    }

	    // Mélanger les lettres en utilisant l'algorithme de Fisher-Yates
	    for (int i = 0; i < longueurDuMot; i++) {
	        // Sélection d'un index aléatoire dans le tableau
	        int j = random.nextInt(longueurDuMot - i) + i;

	        // Échange des caractères
	        swapLetters(lettres, i, j);
	    }

	    // Conversion du tableau de caractères en chaîne
	    String resultat = new String(lettres);

	    // Retour du résultat
	    return resultat;
	}

	/**
	 * Méthode auxiliaire pour échanger deux caractères dans un tableau.
	 *
	 * @param lettres le tableau de caractères
	 * @param i       l'index du premier caractère
	 * @param j       l'index du second caractère
	 */
	/**
	 * Échange deux lettres dans un tableau de caractères.
	 * Cette méthode prend les indices des lettres à échanger et effectue l'échange.
	 * 
	 * @param lettres Le tableau de caractères contenant les lettres.
	 * @param i L'indice de la première lettre dans le tableau.
	 * @param j L'indice de la seconde lettre dans le tableau.
	 */
	private void swapLetters(char[] lettres, int i, int j) {
	    // Vérification de la validité des indices et du tableau
	    if (lettres != null && i >= 0 && j >= 0 && i < lettres.length && j < lettres.length) {
	        // Vérification que les indices ne sont pas identiques
	        if (i != j) {
	            // Mémorisation de la lettre à la position 'i'
	            char temp = lettres[i];

	            // Commentaire détaillé sur le processus d'échange
	            // La lettre à la position 'i' est remplacée par la lettre à la position 'j'
	            lettres[i] = lettres[j];

	            // La lettre à la position 'j' est remplacée par la lettre mémorisée précédemment (temp)
	            lettres[j] = temp;

	            // À ce stade, les lettres aux positions 'i' et 'j' ont été échangées
	        } else {
	            // Si les indices sont identiques, aucun échange n'est nécessaire.
	            // On pourrait éventuellement écrire une logique pour gérer ce cas spécifique si nécessaire.
	            System.out.println("Les indices sont identiques, aucun échange effectué.");
	        }
	    } else {
	        // Les conditions de sécurité ne sont pas remplies, donc l'opération n'est pas effectuée.
	        // Ceci est généralement un endroit pour la gestion des erreurs ou les logs.
	        System.out.println("Opération d'échange non effectuée en raison de paramètres non valides.");
	    }
	}



	private class GestionnaireClicAide implements EventHandler<MouseEvent> {
		@Override
		public void handle(MouseEvent event) {
			// Affiche une alerte lors d'un clic sur un élément associé à cet écouteur d'événement
			newAlert();
		}
	}
}
