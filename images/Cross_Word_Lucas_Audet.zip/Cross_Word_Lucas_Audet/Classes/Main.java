package application;
	
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        try {
            // Initialisation de l'interface utilisateur graphique avec le thème et les données correspondants
            final String theme = "Sport";
            final String fichierDonnees = "Info/donneesSport.txt";
            final String fichierGrille = "Info/grilleSport.txt";
            InterfaceGraphique interfaceGraphique = new InterfaceGraphique(theme, fichierDonnees, fichierGrille);

            // Préparation du conteneur principal de l'interface utilisateur
            BorderPane root = preparerConteneurPrincipal(interfaceGraphique);

            // Configuration de la scène principale
            final double largeurScene = 820.0;
            final double hauteurScene = 620.0;
            Scene scene = new Scene(root, largeurScene, hauteurScene);

            // Configuration de la fenêtre de l'application (la scène principale)
            configurerFenetrePrincipale(primaryStage, scene);

            // Appliquer les feuilles de style
            ajouterFeuillesDeStyle(scene);

            // Affichage de la fenêtre de l'application
            primaryStage.show();
        } catch (Exception e) {
            // Gestion des exceptions en imprimant la trace de la pile
            e.printStackTrace();
        }
    }

    private BorderPane preparerConteneurPrincipal(InterfaceGraphique interfaceGraphique) {
        // Récupération et retour du conteneur principal de l'interface graphique
        return interfaceGraphique.getBorderPane();
    }

    private void configurerFenetrePrincipale(Stage primaryStage, Scene scene) {
        // Définition du titre de la fenêtre
        final String titreFenetre = "Mots croisés";
        primaryStage.setTitle(titreFenetre);

        // Empêcher le redimensionnement de la fenêtre
        primaryStage.setResizable(false);

        // Définir la scène pour le stage
        primaryStage.setScene(scene);
    }

    private void ajouterFeuillesDeStyle(Scene scene) {
        // Chemin d'accès à la feuille de style
        final String cheminFeuilleDeStyle = "application.css";

        // Ajout de la feuille de style à la scène
        scene.getStylesheets().add(getClass().getResource(cheminFeuilleDeStyle).toExternalForm());
    }

    public static void main(String[] args) {
        // Lancement de l'application
        launch(args);
    }
}
