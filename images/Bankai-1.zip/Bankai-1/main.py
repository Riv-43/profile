import os
from discord.ext import commands

TOKEN = ""

prefix = '!'
bot = commands.Bot(command_prefix=prefix)

#Confirmation

@bot.event
async def on_ready():
  print('We have logged in as {0.user}'.format(bot))
  activity = discord.Game(name = "with his bankai") 
  await bot.change_presence(status=discord.Status.online, activity=activity)

#Utils

@bot.command()
async def ping(ctx):
  await ctx.send(f"Im alive : {round(bot.latency, 1)}")
#Repeateword

@bot.command()
async def say(ctx, arg):
    await ctx.send(arg)


#Hello back + nickname

@bot.command() 
async def hello(ctx): # Nom de la comande
    pseudo = ctx.message.author.name #Attribu le pseudo dans la variable pseudo
    await ctx.send("Hellooo {}".format(pseudo)) #écrit le "Salut + le pseudo" 

#repeatecompletly

@bot.command()
async def send(ctx, *, arg):
    await ctx.send(arg)

#slap

@bot.command()
async def slap(ctx, members: commands.Greedy[discord.Member], *, reason='no reason'):
    slapped = ", ".join(x.name for x in members)
    await ctx.send('{} just got slapped for {}'.format(slapped, reason))
    

    
    

  #ban commands

import typing

@bot.command()
@commands.has_any_role("Octagram")
async def ban(ctx, members: commands.Greedy[discord.Member],
                   delete_days: typing.Optional[int] = 0, *,
                   reason: str):
    """Mass bans members with an optional delete_days parameter"""
    for member in members:
        await ctx.message.delete()
        await member.ban(delete_message_days=delete_days, reason=reason)


#role command
@bot.command(pass_context=True)
@commands.has_permissions(administrator=True)
async def addrole(ctx, user: discord.Member, role: discord.Role):
  try:
    await user.add_roles(role)
    await ctx.send("{} got {} role ".format(user, role))
  except discord.Forbidden:
    await ctx.send("I don't have permission to do this")

@bot.command(pass_context=True)
@commands.has_permissions(administrator=True)
async def removerole(ctx, user: discord.Member, role: discord.Role):
  try:
    await user.remove_roles(role)
    await ctx.send("{} lost {} role ".format(user, role))
  except discord.Forbidden:
    await ctx.send("I don't have permission to do this")

def contains_word(s, w):
    return (' ' + w + ' ') in (' ' + s + ' ')

def containElement(message, table):
    for element in table:
        if contains_word(message, element):
            return True
    return False

@bot.listen() # Permet d'écouter les messages par le bot
async def on_message(message):
  if message.author == bot.user: #Si c'est le bot qui envoie le message on fait rien et on return
    return

  if containElement(message.content.lower(), ["nigger", "faggot","nigga", ":emoji_66:", "b_what"]): #Si un mot banni est dans le message (entre les [] c'est les mots banni) on rentre dans la condition
    await message.delete()#Supprime le message mais tu peux faire d'autres actions dedans genre envoyé un msg dans la console ou dans le salon etc
  
  if message.content.lower().startswith("noot"):
    await message.channel.send("https://c.tenor.com/Q4tVC2cL_woAAAAd/noot-noot-apocalypse.gif")

  if message.content.lower().startswith("bankai"):
    await message.channel.send("https://c.tenor.com/FczmsK5N1hMAAAAC/bankai-bleach.gif")
    
    
  if message.content.lower().startswith("getsuga"):
    await message.channel.send("https://media.discordapp.net/attachments/989044630400147458/1000958494419206205/Screenshot_20220724-224733.png?width=928&height=676")

    

bot.run("OTkzNTk1NzU0ODA1NDY5MjI3.GuDwE3.JMam37soz4Cb-PKctnSiqSBtmedgZ2ku1cdt80")