package application;

import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Font;
import javafx.geometry.Pos;
import javafx.scene.Group;

public class Win extends Stage {

    public Win() {
        VBox layout = new VBox(10);
        layout.setAlignment(Pos.CENTER);

        Image backgroundImage = new Image("icone.png");
        BackgroundImage background = new BackgroundImage(backgroundImage, 
                                                         BackgroundRepeat.REPEAT, 
                                                         BackgroundRepeat.REPEAT, 
                                                         BackgroundPosition.CENTER, 
                                                         new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, true));
        layout.setBackground(new Background(background));

        Image gifImage = new Image("award.gif");
        ImageView gifView = new ImageView(gifImage);
        gifView.setFitHeight(100);
        gifView.setFitWidth(100);
        
        
        Group medail = new Group(gifView);
        medail.setTranslateX(-100);
        
        layout.getChildren().add(medail);
        

        //Retourner au menu
        Button returnMenuButton = new Button("Retour au menu");
        returnMenuButton.setFont(new Font("Arial", 16));
        returnMenuButton.setMinWidth(100);
        returnMenuButton.setOnAction(event -> {
            this.close();
            try {
                close();
                RushHourMenu menu = new RushHourMenu();
                menu.show();
            } catch (Exception e) {
            }
        });

        Label message = new Label("Vous avez gagné!");
        message.setFont(new Font("Arial", 20));
        layout.getChildren().addAll(message, returnMenuButton);

        Scene scene = new Scene(layout, 450, 300);
        this.setTitle("Win");
        this.setScene(scene);
    }
}