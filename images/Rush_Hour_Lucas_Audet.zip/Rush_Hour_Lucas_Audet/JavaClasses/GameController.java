package application;

/**
 * Classe GameController gère la logique du jeu, y compris le suivi des mouvements et l'état du plateau.
 */

public class GameController {
    private Boolean [][] board;
    private int moveCount;
    
    /**
     * Constructeur pour GameController.
     * Initialise le plateau de jeu et met le compteur de mouvements à zéro.
     */

    public GameController() {
    	Boolean[][] table = new Boolean[8][8];
        for(int i = 0; i < 8; i++) {
        	for(int j = 0; j < 8; j++) {
        		table[i][j] = false;
        	}
        }
        
        for(int i = 1; i < 7; i++) {
        	for(int j = 1; j < 7; j++) {
        		table[i][j] = true;
        	}
        }
        
        
        table[7][3] =true;
        
        this.board = table;
        this.moveCount = 0;
    }
    
    /**
     * Réinitialise le GameController et le plateau de jeu.
     */
    
    public void startGameController() {
    	Boolean[][] table = new Boolean[8][8];
        for(int i = 0; i < 8; i++) {
        	for(int j = 0; j < 8; j++) {
        		table[i][j] = false;
        	}
        }
        
        for(int i = 1; i < 7; i++) {
        	for(int j = 1; j < 7; j++) {
        		table[i][j] = true;
        	}
        }
        
        
        table[7][3] =true;
        
        this.board = table;
        this.moveCount = 0;
    }
    
    /**
     * Incrémente le compteur de mouvements et affiche le nombre actuel de mouvements.
     */

    public void addCount() {
    	moveCount++;
    	System.out.println(moveCount);
    }
    
    /**
     * Retourne le nombre de mouvements sous forme de chaîne de caractères.
     * 
     * @return Le nombre de mouvements effectués sous forme de String.
     */
    
    public String getMoveCount() {
    	return Integer.toString(moveCount);
    }
    
    /**
     * Réinitialise le compteur de mouvements à zéro.
     */
    
    public void resetMoveCount() {
    	moveCount = 0;
    }
    
    /**
     * Retire un véhicule du plateau.
     * 
     * @param vehicle Le véhicule à retirer.
     */
    
    public void remove(Vehicle vehicle) {
    	for(int i = 0; i < vehicle.getLength(); i++) {
    		board[vehicle.getX(i) + 1] [vehicle.getY(i) + 1] = true;
    	}
    }
    
    /**
     * Place un véhicule sur le plateau.
     * 
     * @param vehicle Le véhicule à placer.
     */
    
    public void place(Vehicle vehicle) {
    	for(int i = 0; i < vehicle.getLength(); i++) {
    		board[vehicle.getX(i) + 1] [vehicle.getY(i) + 1] = false;
    	}
    }
    
    /**
     * Affiche l'état actuel du plateau.
     */
    
    public void displayData() {
    	System.out.println("Display of data:\n");
    	for(int i = 1; i < 7; i++) {
    		System.out.println();
    		for(int j = 1; j < 7; j++) {
    			if(board[j][i]) {
    				System.out.print("O ");
    			}
    			else {
    				System.out.print("X ");
    			}
    		}
    	}
    	
    }
    
    /**
     * Vérifie si une cellule spécifique du plateau est occupée.
     * 
     * @param x Position X de la cellule à vérifier.
     * @param y Position Y de la cellule à vérifier.
     * @return true si la cellule est occupée, false sinon.
     */
    
    public boolean isCellOccupied(int x, int y) {
    	try {
        return !board[x + 1][y + 1];
    	}catch(Exception e) {
    		return true;
    	}
    }
    
    /**
     * Vérifie si un véhicule peut se déplacer vers une cellule cible sans être bloqué.
     * 
     * @param vec Le véhicule à déplacer.
     * @param targetX Position X cible du véhicule.
     * @param targetY Position Y cible du véhicule.
     * @return true si le chemin vers la cellule cible est bloqué, false sinon.
     */
    
    public boolean isCellBlocking(Vehicle vec, int targetX, int targetY) {

        int dx = vec.getDirection() == Direction.HORIZONTAL ? (targetX > vec.getX(0) ? 1 : -1) : 0;
        int dy = vec.getDirection() == Direction.VERTICAL ? (targetY > vec.getY(0) ? 1 : -1) : 0;

        int checkX = vec.getX(0) + dx;
        int checkY = vec.getY(0) + dy;

        while ((dx > 0 && checkX <= targetX) || (dx < 0 && checkX >= targetX) ||
               (dy > 0 && checkY <= targetY) || (dy < 0 && checkY >= targetY)) {

            if (isCellOccupied(checkX, checkY)) {
                return true;
            }
            
            checkX += dx;
            checkY += dy;
        }

        return false;
    }





    
}
