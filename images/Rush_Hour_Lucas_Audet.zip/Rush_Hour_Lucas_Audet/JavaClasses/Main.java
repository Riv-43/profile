package application;

import javafx.application.Application;
import javafx.stage.Stage;

/**
 * Classe principale pour l'application Rush Hour.
 * Cette classe étend la classe Application de JavaFX pour créer une interface utilisateur.
 */
public class Main extends Application {
    
    /**
     * Démarre l'application JavaFX.
     * Cette méthode est appelée automatiquement lors du lancement de l'application.
     * 
     * @param primaryStage Le stage principal pour cette application, sur lequel la scène est placée.
     */
    @Override
    public void start(Stage primaryStage) {
        RushHourMenu menuPrincipal = new RushHourMenu();
        menuPrincipal.show();
    }

    /**
     * Point d'entrée principal de l'application.
     * Cette méthode lance l'application JavaFX.
     * 
     * @param args Les arguments de ligne de commande passés à l'application.
     */
    public static void main(String[] args) {
        launch(args);
    }
}
