package application;

public enum Direction {
    HORIZONTAL,
    VERTICAL
}
