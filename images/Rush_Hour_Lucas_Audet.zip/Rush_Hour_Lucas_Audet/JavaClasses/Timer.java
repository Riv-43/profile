package application;

/**
 * La classe Timer est utilisée pour suivre le temps écoulé en secondes.
 */
public class Timer {

    private int nbrseconde;

    /**
     * Constructeur pour Timer.
     * Initialise le compteur de secondes à 0.
     */
    public Timer() {
        this.nbrseconde = 0;
    }

    /**
     * Incrémente le nombre de secondes de 1.
     * Cette méthode doit être appelée chaque seconde pour mettre à jour le compteur de temps.
     */
    public void addMore() {
        nbrseconde++;
    }

    /**
     * Retourne une représentation sous forme de chaîne de caractères du temps écoulé.
     * 
     * @return Le nombre de secondes écoulées depuis le début du chronométrage sous forme de String.
     */
    @Override
    public String toString() {
        return nbrseconde + "";
    }
}
