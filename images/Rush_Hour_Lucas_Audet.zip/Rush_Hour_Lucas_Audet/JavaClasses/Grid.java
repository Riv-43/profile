package application;

import java.util.List;

/**
 * La classe Grid représente la grille de jeu pour un niveau donné.
 * Elle contient une matrice de véhicules ainsi qu'une liste de véhicules présents dans le niveau.
 */

public class Grid {
    private Vehicle[][] grid;
    private List<Vehicle> vehicles;
    private GameLevel level;
    
    /**
     * Constructeur de la classe Grid.
     * Initialise la grille pour un niveau de jeu spécifique.
     *
     * @param level Le niveau de jeu (par exemple, FACILE, MOYEN, DIFFICILE) pour lequel la grille est créée.
     */

    public Grid(GameLevel level) {
        this.level = level;
     // Initialisation de la grille et chargement des véhicules en fonction du niveau pourraient être ajoutés ici.
    }

}
