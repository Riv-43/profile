package application;

public enum GameLevel {
    FACILE,
    MOYEN,
    DIFFICILE
}
