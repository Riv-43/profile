package application;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.ArrayList;

/**
 * La classe ConfigReader est utilisée pour lire la configuration des véhicules à partir d'un fichier.
 * Elle charge les données des véhicules en fonction du niveau de jeu spécifié.
 */
public class ConfigReader {
    private List<Vehicle> vehicles = new ArrayList<>();

    /**
     * Constructeur pour ConfigReader.
     * Charge les données de configuration des véhicules depuis un fichier spécifique, basé sur le niveau de jeu.
     *
     * @param level Le niveau de jeu (FACILE, MOYEN, DIFFICILE) qui détermine le fichier de configuration à lire.
     * @throws IOException Si une erreur de lecture de fichier se produit.
     */
    public ConfigReader(GameLevel level) throws IOException {
        String filePath = "";
        switch (level) {
            case FACILE:
                filePath = "Info/facile.txt";
                break;
            case MOYEN:
                filePath = "Info/moyen.txt";
                break;
            case DIFFICILE:
                filePath = "Info/difficile.txt";
                break;
        }
        readConfig(filePath);
    }

    /**
     * Lit la configuration des véhicules à partir du fichier spécifié.
     * Parse chaque ligne du fichier et crée des objets Vehicle.
     *
     * @param filePath Le chemin vers le fichier de configuration.
     * @throws IOException Si une erreur de lecture de fichier ou de format de ligne se produit.
     */
    public void readConfig(String filePath) throws IOException {
        List<String> lines = Files.readAllLines(Paths.get(filePath));

        for (String line : lines) {
            String[] parts = line.split(",");
            if (parts.length != 5) {
                throw new IOException("Invalid line format: " + line);
            }

            String color = parts[0];
            int length = Integer.parseInt(parts[1]);
            int x = Integer.parseInt(parts[2]);
            int y = Integer.parseInt(parts[3]);
            char orientation = parts[4].charAt(0);

            Direction ori = Direction.HORIZONTAL;

            if (orientation == 'V') {
                ori = Direction.VERTICAL;
            }

            Vehicle vehicle = new Vehicle(color, length, x, y, ori);
            vehicles.add(vehicle);
        }
    }

    /**
     * Retourne la liste des véhicules chargés.
     * 
     * @return La liste des objets Vehicle chargés à partir du fichier de configuration.
     */
    public List<Vehicle> getArray() {
        return vehicles;
    }
}
