package application;

import java.util.ArrayList;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * La classe Vehicle représente un véhicule dans le jeu.
 * Elle contient des informations sur la position, la couleur, la direction et la taille du véhicule.
 */
public class Vehicle {
    private String color;
    private Direction direction;
    private ArrayList<Integer> rowList;
    private ArrayList<Integer> colList;
    private Boolean main;
    private int initialX;
    private int initialY;
    
    /**
     * Constructeur pour Vehicle.
     *
     * @param color La couleur du véhicule.
     * @param length La longueur du véhicule.
     * @param col La colonne de départ du véhicule.
     * @param row La rangée de départ du véhicule.
     * @param direction La direction du véhicule (VERTICAL ou HORIZONTAL).
     */
    public Vehicle(String color, int length, int col, int row, Direction direction) {
    	this.color = color;
    	this.direction = direction;
    	this.main = isItRed(color);
    	this.initialX = col;
        this.initialY = row;
    	ArrayList<Integer> rowList = new ArrayList<>();
    	ArrayList<Integer> colList = new ArrayList<>();
    	for(int i = 0; i < length; i++) {
    		if(direction == Direction.VERTICAL) {
    			rowList.add(row + i);
    			colList.add(col);
    		}
    		else if(direction == Direction.HORIZONTAL) {
    			rowList.add(row);
    			colList.add(col + i);
    		}
    		
    		else {
    			System.out.println("Une erreur pour la lecture du fichier");
    			return;
    		}
    	}
    	
    	this.rowList = rowList;
    	this.colList = colList;
    	
    }
    
    /**
     * Retourne une ImageView représentant le véhicule.
     * 
     * @return ImageView du véhicule.
     */
    public ImageView getCarImage() {
    	
    	String fileName = "/";
        
        if(colList.size() == 2) {
        	fileName = fileName + "auto";
        }
        
        else if(colList.size() == 3) {
        	fileName = fileName + "camion";
        }
        
        else {
        	System.out.println("Erreur dans Vehicle.java\nOn ne peut pas lire la longueur");
        }
        
        String orientation = (direction == Direction.HORIZONTAL) ? "H" : "V";
        fileName = fileName + "_" + orientation + "_" + color + ".gif";
        
        Image image = new Image(getClass().getResourceAsStream(fileName));
        return new ImageView(image);
    }
    
    /**
     * Vérifie si le véhicule est de couleur rouge.
     * 
     * @param couleur La couleur à vérifier.
     * @return true si la couleur est rouge, false sinon.
     */
    private static boolean isItRed(String couleur) {
    	if(couleur.equals("rouge")) {
    		return true;
    	}
    	return false;
    }
    
    /**
     * Vérifie si le véhicule est le véhicule principal (rouge).
     * 
     * @return true si le véhicule est le principal, false sinon.
     */
    public Boolean mainCar() {
    	return main;
    }
    
    /**
     * Réinitialise la position du véhicule à sa position initiale.
     */
    public int getX(int index) {
    	return this.colList.get(index);
    }
    
    
    public int getY(int index) {
    	return this.rowList.get(index);
    }
    public Direction getDirection() {
    	return this.direction;
    }
    public int getLength() {
    	return this.rowList.size();
    }
    
    
    public void setX(int index, int x) {
    	this.colList.set(index, x);
    }
    
    public void setY(int index, int y) {
    	this.rowList.set(index, y);
    }
    
    public ArrayList<Integer> getArrayX(){
    	return colList;
    }
    
    public ArrayList<Integer> getArrayY(){
    	return rowList;
    }
    
    public void resetPosition() {
    	int length = this.getLength();
    	this.colList.clear();
    	this.rowList.clear();
    	for(int i = 0; i < length; i++) {
    		if(direction == Direction.VERTICAL) {
    			rowList.add(initialY + i);
    			colList.add(initialX);
    		}
    		else if(direction == Direction.HORIZONTAL) {
    			rowList.add(initialY);
    			colList.add(initialX + i);
    		}
    	}
    }
    
    public int getInitialX() {
        return initialX;
    }

    public int getInitialY() {
        return initialY;
    }
    
}
