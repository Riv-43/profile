package application;

import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.CornerRadii;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import java.io.IOException;

/**
 * La classe RushHourMenu sert d'écran de menu pour le jeu Rush Hour.
 * Elle permet aux utilisateurs de choisir le niveau de difficulté avant de commencer le jeu.
 */

public class RushHourMenu extends Stage {

    private VBox root;
    
    /**
     * Constructeur de RushHourMenu.
     * Initialise l'interface utilisateur du menu principal du jeu.
     */

    public RushHourMenu() {

        root = new VBox(20); 
        root.setAlignment(Pos.CENTER);
        root.setBackground(new Background(new BackgroundFill(Color.DARKBLUE, CornerRadii.EMPTY, Insets.EMPTY)));

        ImageView logoView = new ImageView(new Image(getClass().getResourceAsStream("/logo.gif")));
        logoView.setFitHeight(100);
        logoView.setPreserveRatio(true);

        HBox levelBox = new HBox(20);
        levelBox.setAlignment(Pos.CENTER);

        Button facileButton = createLevelButton("/mini_facile.png");
        Button moyenButton = createLevelButton("/mini_moyen.png");
        Button difficileButton = createLevelButton("/mini_diff.png");

        facileButton.setOnAction(event -> {
			try {
				startGame(GameLevel.FACILE);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
        moyenButton.setOnAction(event -> {
			try {
				startGame(GameLevel.MOYEN);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
        difficileButton.setOnAction(event -> {
			try {
				startGame(GameLevel.DIFFICILE);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});

        levelBox.getChildren().addAll(facileButton, moyenButton, difficileButton);

        root.getChildren().addAll(logoView, levelBox);

        Scene scene = new Scene(root, 824, 568);
        this.setTitle("Rush Hour");
        this.setScene(scene);
    }
    
    /**
     * Crée un bouton pour sélectionner le niveau de jeu.
     * 
     * @param imagePath Le chemin de l'image représentant le niveau.
     * @return Un bouton avec une image.
     */
    

    private Button createLevelButton(String imagePath) {
        Image image = new Image(getClass().getResourceAsStream(imagePath));
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(150);
        imageView.setPreserveRatio(true);
        Button button = new Button("", imageView);
        button.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
        return button;
    }
    
    /**
     * Lance le jeu avec le niveau sélectionné.
     * 
     * @param level Le niveau de jeu sélectionné.
     * @throws IOException Si une erreur survient lors du lancement du jeu.
     */

    private void startGame(GameLevel level) throws IOException {

        Stage currentStage = (Stage) root.getScene().getWindow();
        Game game = new Game(currentStage, level);
        currentStage.setScene(game.getGameScene());
        
    }
}
