package application;

import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.layout.VBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Font;
import javafx.scene.paint.Color;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundSize;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.scene.shape.Rectangle;
import java.util.List;
import java.util.ArrayList;
import java.io.IOException;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.util.Duration;
import java.util.HashMap;
import java.util.Map;


/**
 * La classe Game représente la scène principale du jeu.
 * Elle gère l'affichage de l'interface utilisateur et la logique du jeu.
 */
public class Game extends Stage {
    private Scene gameScene;
    private GridPane gameGridPane;
    private GameLevel level;
    private static Stage stage;
    private static List<Vehicle> vehicles = new ArrayList<>();
    private GameController gameData = new GameController();
    private static Map<Vehicle, Point2D> initialPositions = new HashMap<>();
    private Label moveCountLabel;
    private int minutes;
    private int seconds;
    
    /**
     * Constructeur pour Game.
     * Initialise le jeu avec un niveau donné et configure l'interface utilisateur.
     *
     * @param stage Le stage sur lequel la scène du jeu est affichée.
     * @param level Le niveau de jeu (par exemple FACILE, MOYEN, DIFFICILE).
     * @throws IOException Si une erreur de lecture de fichier se produit.
     */
    public Game(Stage stage, GameLevel level) throws IOException {
        this.stage = stage;
        this.level = level;
        ConfigReader reader = new ConfigReader(level);
        vehicles = reader.getArray();
        initializeUI(level);
    }
    
    /**
     * Initialise l'interface utilisateur pour le niveau de jeu donné.
     *
     * @param level Le niveau de jeu pour lequel l'interface est initialisée.
     */
    private void initializeUI(GameLevel level) {
    	
        BorderPane borderPane = new BorderPane();

        Image backgroundImage = new Image("jaunenoir.gif");

        BackgroundSize bgSize = new BackgroundSize(
            100, 100, 
            true, true, 
            false, true);

        BackgroundImage bgImage = new BackgroundImage(
            backgroundImage, 
            BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, 
            BackgroundPosition.CENTER, 
            bgSize);

        borderPane.setBackground(new Background(bgImage));
        
        Image grilleImg = new Image("grille.gif");
        ImageView backgroundImageView = new ImageView(grilleImg);
        
        backgroundImageView.setPreserveRatio(true);
        
        GridPane gridPane = new GridPane();
        getGridPane(gridPane);
        
        StackPane grille = new StackPane();
        grille.getChildren().addAll(backgroundImageView, gridPane);
        
        grille.setAlignment(Pos.CENTER);
        
        VBox sidePanel = new VBox(20);
        sidePanel.setPadding(new Insets(20));
        sidePanel.setStyle("-fx-background-color: #;");
        sidePanel.setMaxSize(200, 100);
        sidePanel.setMinSize(200, 700);
        sidePanel.setAlignment(Pos.CENTER_LEFT);
        sidePanel.setTranslateX(20);
        sidePanel.setTranslateY(25);
        
        Color grayTransparent = Color.gray(0.8, 0.8);
        CornerRadii cornerRadii = new CornerRadii(20);

        sidePanel.setBackground(new Background(new BackgroundFill(grayTransparent, cornerRadii, Insets.EMPTY)));

        moveCountLabel = new Label(gameData.getMoveCount());
        moveCountLabel.setFont(new Font("Arial", 16));
        moveCountLabel.setAlignment(Pos.CENTER);
        moveCountLabel.setMinSize(50, 50);
        moveCountLabel.setMaxSize(50, 50);
        moveCountLabel.setStyle("-fx-border-color: black; -fx-border-width: 1; -fx-padding: 5;");

        Label moveCountDescLabel = new Label("Nombre de coups joué");
        moveCountDescLabel.setFont(new Font("Arial", 12));
        moveCountDescLabel.setAlignment(Pos.CENTER);

        Label timerLabel = new Label("00:00");
        timerLabel.setFont(new Font("Arial", 24));
        String[] timeParts = timerLabel.getText().split(":");
        minutes = Integer.parseInt(timeParts[0]);
        seconds = Integer.parseInt(timeParts[1]);

        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
        	seconds++;
        	if (seconds > 59) {
        		minutes++;
                seconds = 0;
            }
        	
            timerLabel.setText(String.format("%02d:%02d", minutes, seconds));
            
        }));
        
        Timeline update = new Timeline(new KeyFrame(Duration.seconds(0.5), event -> {
            
        	moveCountLabel.setText(gameData.getMoveCount());

            
            
        }));
        
        update.setCycleCount(Timeline.INDEFINITE);

        update.play();

        timeline.setCycleCount(Timeline.INDEFINITE);

        timeline.play();
        
        Button resetButton = new Button("Réinitialiser");
        resetButton.setFont(new Font("Arial", 16));
        resetButton.setMinWidth(100);
        resetButton.setOnAction(event -> {
        	getGridPane(gridPane);
        	moveCountLabel.setText(gameData.getMoveCount());
        	gameData.resetMoveCount();
        	timerLabel.setText(gameData.getMoveCount());
        });

        Button returnMenuButton = new Button("Retour au menu");
        returnMenuButton.setFont(new Font("Arial", 16));
        returnMenuButton.setMinWidth(100);
        returnMenuButton.setOnAction(event -> {
        	stage.close();
            try {
                close();
                RushHourMenu menu = new RushHourMenu();
                menu.show();
            } catch (Exception e) {}
        });

        sidePanel.getChildren().addAll(timerLabel, moveCountLabel, moveCountDescLabel, resetButton, returnMenuButton);
                
        borderPane.setLeft(sidePanel);
        
        borderPane.setCenter(grille);

        gameScene = new Scene(borderPane, 1024, 768);
        
        stage.setScene(gameScene);
        stage.show();
    }
    
    /**
     * Retourne la scène du jeu.
     * 
     * @return La scène actuelle du jeu.
     */
    public Scene getGameScene() {
        return gameScene;
    }
    
    /**
     * Configure le GridPane pour le jeu.
     * Place les véhicules et configure leurs interactions.
     * 
     * @param gridPane Le GridPane à configurer.
     */
    public void getGridPane(GridPane gridPane) {
    	
    	gridPane.setAlignment(Pos.CENTER);
        
        gridPane.setPadding(new Insets(0, 4, 22, 0));
        
        
    	gridPane.getChildren().clear();
    	Rectangle[] rct = new Rectangle[6];
        for(int i = 0; i < rct.length; i++) {
        	rct[i] = new Rectangle(72, 72, Color.TRANSPARENT);
        	gridPane.add(rct[i], i, i);
        }
        
        
		for(Vehicle vec : vehicles) {
        	vec.resetPosition();
		}
		
		this.gameData = new GameController();

		for(Vehicle vec : vehicles) {
            initialPositions.put(vec, new Point2D(vec.getX(0), vec.getY(0)));
        	
        	ImageView vehicleImage = vec.getCarImage();
        	
        	Group vehicleGroup  = new Group(vehicleImage);
        	
        	if(vec.getDirection() == Direction.HORIZONTAL) {
        		vehicleGroup .setLayoutX(vec.getLength());
        		vehicleGroup .setLayoutY(1);
        	}
        	else {
        		vehicleGroup .setLayoutX(1);
        		vehicleGroup .setLayoutY(vec.getLength());
        	}
        	
        	gameData.place(vec);
        	
        	
        	final double GRID_CELL_WIDTH = 72;
        	final double GRID_CELL_HEIGHT = 72;
        	
        	final double[] initialTranslateX = new double[1];
        	final double[] initialTranslateY = new double[1];
        	final double[] initialMouseX = new double[1];
        	final double[] initialMouseY = new double[1];

        	vehicleGroup.setOnMousePressed(event -> {

        		initialMouseX[0] = event.getSceneX();
        	    initialMouseY[0] = event.getSceneY();
        	    initialTranslateX[0] = vehicleGroup.getTranslateX();
        	    initialTranslateY[0] = vehicleGroup.getTranslateY();
        	    
        	    for(int i = 0; i < vec.getLength(); i++) {
        	    }

        	    vehicleGroup.toFront();
        	    gameData.remove(vec);
        	    
        	});
        	
        	
        	
        	vehicleGroup.setOnMouseDragged(event -> {
        	    double offsetX = event.getSceneX() - initialMouseX[0];
        	    double offsetY = event.getSceneY() - initialMouseY[0];

        	    int tentativeDeltaX = (int) Math.round(offsetX / GRID_CELL_WIDTH);
        	    int tentativeDeltaY = (int) Math.round(offsetY / GRID_CELL_HEIGHT);
        	    

        	    boolean canMove = true;

        	    for (int i = 0; i < vec.getLength(); i++) {
        	    	int newX = vec.getX(i) + (vec.getDirection() == Direction.HORIZONTAL ? tentativeDeltaX : 0);
        	        int newY = vec.getY(i) + (vec.getDirection() == Direction.VERTICAL ? tentativeDeltaY : 0);
        	        
        	        if(vec.getDirection() == Direction.VERTICAL) {
        	        	if (newY < 0 || newY >= 7) {
            	            canMove = false;
            	            break;
            	        }
        	        	
        	        	else {
        	        		if(newX < 0 || newX >=7) {
        	        			canMove = false;
        	        			break;
        	        		}
        	        	}
        	        }
        	        

        	        if (gameData.isCellOccupied(newX, newY) || gameData.isCellBlocking(vec, newX, newY)) {
        	            canMove = false;
        	            break;
        	        }
        	    }

        	    if (canMove) {
        	        if (vec.getDirection() == Direction.HORIZONTAL) {
        	            vehicleGroup.setTranslateX(initialTranslateX[0] + offsetX);
        	        } else if (vec.getDirection() == Direction.VERTICAL) {
        	            vehicleGroup.setTranslateY(initialTranslateY[0] + offsetY);
        	        }
        	    }
        	});
        	
        	vehicleGroup.setOnMouseReleased(event -> {
        		
        	    int deltaX = (int) Math.round((vehicleGroup.getTranslateX() - initialTranslateX[0]) / GRID_CELL_WIDTH);
        	    int deltaY = (int) Math.round((vehicleGroup.getTranslateY() - initialTranslateY[0]) / GRID_CELL_HEIGHT);

        	    for (int i = 0; i < vec.getLength(); i++) {
        	        vec.setX(i, vec.getX(i) + deltaX);
        	        vec.setY(i, vec.getY(i) + deltaY);
        	    }
        	    
        	    vehicleGroup.setTranslateX(deltaX * GRID_CELL_WIDTH + initialTranslateX[0]);
        	    vehicleGroup.setTranslateY(deltaY * GRID_CELL_HEIGHT + initialTranslateY[0]);

        	    gameData.addCount();
        	    gameData.place(vec);

        	    if (vec.mainCar() && (vec.getX(0) == 5 || vec.getX(1) == 5)) {
        	        
        	        stage.close();
        	        Win winStage = new Win();
        	        winStage.show();
        	    }
        	});
        	
            int x = vec.getX(0);
            int y = vec.getY(0);
            if(vec.getDirection() == Direction.HORIZONTAL) {
                gridPane.add(vehicleGroup , x, y, vec.getLength(), 1);
            } else {
                gridPane.add(vehicleGroup , x, y, 1, vec.getLength());
            }
            
        }

    }
    
    
}
